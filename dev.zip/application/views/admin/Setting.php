<div class="container-fluid">

<table class="table">
<tr><th>Setting</th><th>Description</th></tr>
<tr><td><a href=''>User Role Management</a></td><td>Here you can manage your User Roles </td></tr>
<tr><td><a href=''>Profile Management</a></td><td>Here you can manage your Profile,edit name ,email... </td></tr>

</table>

</div>