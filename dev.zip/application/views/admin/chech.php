
<?php
  $ojbect = $this->barcode->getBarCode("hello arti");
  echo $ojbect->getBarcodeHTML(2, 30, 'black');
  ?>
